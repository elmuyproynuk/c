#include "Menu.hpp"
#include "Neon.hpp"

#include <Geode/modify/CCScheduler.hpp>
#include <Geode/modify/GJGameLevel.hpp>
#include <Geode/modify/GameManager.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>

using namespace cmm;

namespace {

float rnd(float a, float b) { return a + (b - a) * (std::rand() / (float)RAND_MAX); }

bool cheatsActive() {
	return cmm::on("noclip") || (cmm::on("speed_on") && std::fabs(cmm::get("speed") - 1.0) > 0.001);
}

// ---------------------------------------------------------------- particle trail
// Tiny CPU particle system drawn with one CCDrawNode (no textures / plists needed).
class TrailFx : public CCNode {
public:
	struct P { CCPoint pos, vel; float age, life, size, rot, seed; int style; ccColor4F col; };
	std::vector<P> m_ps;
	CCDrawNode* m_draw = nullptr;
	float m_acc = 0.f, m_hue = 0.f;

	static TrailFx* create() {
		auto r = new TrailFx();
		if (r && r->init()) {
			r->m_draw = CCDrawNode::create();
			setBlend(r->m_draw, true); // additive = glowy
			r->addChild(r->m_draw);
			r->autorelease();
			return r;
		}
		delete r;
		return nullptr;
	}

	ccColor4F pickColor() {
		int mode = (int)cmm::get("trail_color");
		if (mode == 0) { m_hue += 0.018f; return hsv(m_hue, 0.55f, 1.f); }
		if (mode == 1) return themeColor(rnd(0.f, 1.f));
		return ccc4f(0.95f, 0.97f, 1.f, 1.f);
	}

	void spawn(CCPoint pos, int style, float size, float life) {
		P p;
		p.pos = CCPoint(pos.x + rnd(-3.f, 3.f), pos.y + rnd(-3.f, 3.f));
		p.age = 0.f;
		p.life = life * rnd(0.7f, 1.15f);
		p.size = size * rnd(0.8f, 1.2f);
		p.rot = rnd(0.f, 6.28f);
		p.seed = rnd(0.f, 6.28f);
		p.style = style;
		p.col = pickColor();
		switch (style) {
			case 0: p.vel = CCPoint(rnd(-35.f, 35.f), rnd(-35.f, 35.f)); break;      // sparks
			case 1: p.vel = CCPoint(rnd(-12.f, 12.f), rnd(25.f, 70.f)); break;       // fire
			case 2: p.vel = CCPoint(rnd(-10.f, 10.f), rnd(10.f, 35.f)); break;       // bubbles
			case 3: p.vel = CCPoint(rnd(-20.f, 20.f), rnd(-20.f, 20.f)); break;      // diamonds
			default: p.vel = CCPoint(rnd(-8.f, 8.f), rnd(-30.f, -10.f)); break;      // snow
		}
		m_ps.push_back(p);
	}

	void tick(float dt, CCPoint pos, bool emit) {
		if (emit) {
			m_acc += dt * (float)cmm::get("trail_density");
			float size = (float)cmm::get("trail_size"), life = (float)cmm::get("trail_life");
			int style = (int)cmm::get("trail_style");
			while (m_acc >= 1.f && m_ps.size() < 500) {
				m_acc -= 1.f;
				spawn(pos, style, size, life);
			}
			m_acc = std::min(m_acc, 3.f);
		} else {
			m_acc = 0.f;
		}

		for (auto& p : m_ps) {
			p.age += dt;
			p.pos = CCPoint(p.pos.x + p.vel.x * dt, p.pos.y + p.vel.y * dt);
			p.rot += dt * 3.f;
			if (p.style == 4) p.pos.x += std::sin(p.age * 3.f + p.seed) * 14.f * dt;
		}
		m_ps.erase(std::remove_if(m_ps.begin(), m_ps.end(), [](P const& p) { return p.age >= p.life; }), m_ps.end());

		m_draw->clear();
		for (auto const& p : m_ps) {
			float t = p.age / p.life, a = 1.f - t;
			float s = p.size * (p.style == 1 ? (1.f - t * 0.8f) : (1.f - t * 0.45f));
			auto c = ccc4f(p.col.r, p.col.g, p.col.b, a * 0.9f);
			switch (p.style) {
				case 0: m_draw->drawDot(p.pos, s * 2.2f, c); break;
				case 1: m_draw->drawDot(p.pos, s * 3.0f, ccc4f(p.col.r, p.col.g, p.col.b, a * 0.55f)); break;
				case 2: m_draw->drawCircle(p.pos, s * 3.f, ccc4f(c.r, c.g, c.b, a * 0.12f), 1.f, c, 12); break;
				case 3: {
					float r = s * 3.2f, co = std::cos(p.rot), si = std::sin(p.rot);
					CCPoint v[4] = {
						CCPoint(p.pos.x + co * r, p.pos.y + si * r), CCPoint(p.pos.x - si * r * 0.6f, p.pos.y + co * r * 0.6f),
						CCPoint(p.pos.x - co * r, p.pos.y - si * r), CCPoint(p.pos.x + si * r * 0.6f, p.pos.y - co * r * 0.6f)};
					m_draw->drawPolygon(v, 4, c, 0.f, ccc4f(0, 0, 0, 0));
					break;
				}
				default: m_draw->drawDot(p.pos, s * 1.6f, ccc4f(0.95f, 0.97f, 1.f, a * 0.9f)); break;
			}
		}
	}
};

// ---------------------------------------------------------------- per-level state
struct PLState {
	CCLabelBMFont* hud = nullptr;
	TrailFx* fx1 = nullptr;
	TrailFx* fx2 = nullptr;
	float hue = 0.f, hudT = 0.f;
	int frames = 0;
	float fps = 0.f;
	std::chrono::steady_clock::time_point last = std::chrono::steady_clock::now();
	bool wasRainbow = false;
	int blocked = 0;
} S;

} // namespace

// =============================================================== PlayLayer
class $modify(CmmPlayLayer, PlayLayer) {
	bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
		if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
		S = PLState();
		auto win = CCDirector::get()->getWinSize();
		S.hud = CCLabelBMFont::create("", "chatFont.fnt");
		S.hud->setAnchorPoint(CCPoint(0.f, 1.f));
		S.hud->setPosition(CCPoint(6.f, win.height - 4.f));
		S.hud->setOpacity(190);
		m_uiLayer->addChild(S.hud, 50);
		return true;
	}

	void destroyPlayer(PlayerObject* player, GameObject* obj) {
		// m_anticheatSpike is the level's anti-cheat spike: never skip that one
		if (cmm::on("noclip") && obj != m_anticheatSpike) {
			bool p1 = player == m_player1;
			if ((p1 && cmm::on("noclip_p1")) || (!p1 && cmm::on("noclip_p2"))) {
				S.blocked++;
				return;
			}
		}
		PlayLayer::destroyPlayer(player, obj);
	}

	void postUpdate(float dt) {
		PlayLayer::postUpdate(dt);

		// ---- HUD (FPS / clock / noclip counter), refreshed 4x per second
		auto now = std::chrono::steady_clock::now();
		float real = std::chrono::duration<float>(now - S.last).count();
		S.last = now;
		S.frames++;
		S.hudT += real;
		if (S.hudT >= 0.25f) {
			S.fps = S.frames / S.hudT;
			S.frames = 0;
			S.hudT = 0.f;
			if (S.hud) {
				std::string text;
				char buf[64];
				if (cmm::on("show_fps")) { std::snprintf(buf, sizeof buf, "FPS %.0f", S.fps); text += buf; }
				if (cmm::on("show_clock")) {
					std::time_t tt = std::time(nullptr);
					std::tm lt{};
#ifdef _WIN32
					localtime_s(&lt, &tt);
#else
					localtime_r(&tt, &lt);
#endif
					std::strftime(buf, sizeof buf, "%H:%M", &lt);
					if (!text.empty()) text += "   ";
					text += buf;
				}
				if (cmm::on("noclip") && cmm::on("noclip_count")) {
					std::snprintf(buf, sizeof buf, "Noclip: %d", S.blocked);
					if (!text.empty()) text += "\n";
					text += buf;
				}
				S.hud->setString(text.c_str());
				S.hud->setScale(0.6f * (float)cmm::get("hud_scale"));
				S.hud->setVisible(!text.empty());
			}
		}

		// ---- rainbow icon
		bool rb = cmm::on("rainbow_icon");
		if (rb) {
			S.hue += dt * 0.25f * (float)cmm::get("rainbow_speed");
			auto c1 = to3B(hsv(S.hue, 0.7f, 1.f));
			auto c2 = to3B(hsv(S.hue + 0.5f, 0.7f, 1.f));
			m_player1->setColor(c1);
			m_player1->setSecondColor(c2);
			if (m_player2) { m_player2->setColor(c2); m_player2->setSecondColor(c1); }
		} else if (S.wasRainbow) {
			auto gm = GameManager::get();
			m_player1->setColor(gm->colorForIdx(gm->getPlayerColor()));
			m_player1->setSecondColor(gm->colorForIdx(gm->getPlayerColor2()));
			if (m_player2) {
				m_player2->setColor(gm->colorForIdx(gm->getPlayerColor2()));
				m_player2->setSecondColor(gm->colorForIdx(gm->getPlayerColor()));
			}
		}
		S.wasRainbow = rb;

		// ---- particle trail
		bool trail = cmm::on("trail_on");
		if (trail && !S.fx1 && m_player1->getParent()) {
			S.fx1 = TrailFx::create();
			m_player1->getParent()->addChild(S.fx1, m_player1->getZOrder() - 1);
			S.fx2 = TrailFx::create();
			m_player1->getParent()->addChild(S.fx2, m_player1->getZOrder() - 1);
		}
		if (S.fx1) S.fx1->tick(dt, m_player1->getPosition(), trail && m_player1->isVisible());
		if (S.fx2 && m_player2) S.fx2->tick(dt, m_player2->getPosition(), trail && m_player2->isVisible());
	}
};

// =============================================================== speedhack
// Scales the engine time step, but only while a level is loaded so menus stay normal.
class $modify(CmmScheduler, CCScheduler) {
	void update(float dt) {
		if (cmm::on("speed_on") && PlayLayer::get()) dt *= (float)cmm::get("speed");
		CCScheduler::update(dt);
	}
};

// =============================================================== safe mode
class $modify(CmmLevel, GJGameLevel) {
	void savePercentage(int percent, bool isPractice, int clicks, int attempts, bool isChkValid) {
		if (cmm::on("safe_mode") && cheatsActive()) return;
		GJGameLevel::savePercentage(percent, isPractice, clicks, attempts, isChkValid);
	}
};

// =============================================================== local unlocks
class $modify(CmmGameManager, GameManager) {
	bool isIconUnlocked(int id, IconType type) {
		if (cmm::on("unlock_icons")) return true;
		return GameManager::isIconUnlocked(id, type);
	}
	bool isColorUnlocked(int id, UnlockType type) {
		if (cmm::on("unlock_colors")) return true;
		return GameManager::isColorUnlocked(id, type);
	}
};

// =============================================================== open from the pause menu
class $modify(CmmPause, PauseLayer) {
	void customSetup() {
		PauseLayer::customSetup();
		if (cmm::get("open_mode") > 0.5) return; // ball mode: no button here
		auto win = CCDirector::get()->getWinSize();
		auto menu = CCMenu::create();
		menu->setPosition(CCPoint(0.f, 0.f));
		auto btn = CCMenuItemSpriteExtra::create(makeNeonIcon(38.f), nullptr, this, menu_selector(CmmPause::onClaude));
		btn->setPosition(CCPoint(win.width - 34.f, 34.f));
		menu->addChild(btn);
		this->addChild(menu, 20);
	}
	void onClaude(CCObject*) { Menu::open(); }
};

// =============================================================== main menu: ball + (optional) button
class $modify(CmmMenuLayer, MenuLayer) {
	bool init() {
		if (!MenuLayer::init()) return false;
		Ball::ensure();
		if (cmm::get("open_mode") < 0.5) {
			if (auto bm = typeinfo_cast<CCMenu*>(this->getChildByID("bottom-menu"))) {
				auto btn = CCMenuItemSpriteExtra::create(makeNeonIcon(36.f), nullptr, this, menu_selector(CmmMenuLayer::onClaude));
				bm->addChild(btn);
				bm->updateLayout();
			}
		}
		return true;
	}
	void onClaude(CCObject*) { Menu::open(); }
};
