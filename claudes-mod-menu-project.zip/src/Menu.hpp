#pragma once
#include "Config.hpp"

namespace cmm {

struct Menu {
	static void open();
	static bool isOpen();
};

struct Ball {
	static void ensure();  // create the floating ball once (kept across scenes)
	static void refresh(); // re-read settings (mode / size / opacity)
};

// Small round neon "C" icon, used by the pause-menu / main-menu button
CCNode* makeNeonIcon(float size);

} // namespace cmm
