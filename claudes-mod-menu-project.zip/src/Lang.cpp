#include "Config.hpp"
#include <algorithm>
#include <array>
#include <unordered_map>

// Translations: {key, Espanol, English, Portugues}
// (No accents / n-tilde on purpose: GD's bitmap fonts don't draw them reliably.)
// To add a language: add a column here + an entry in Config.cpp ("lang" choice) + bump LANGS.
namespace cmm {

struct Row4 { const char* key; const char* v[3]; };
static const Row4 TABLE[] = {
	{"tab_player", {"Jugador", "Player", "Jogador"}},
	{"tab_level", {"Nivel", "Level", "Nivel"}},
	{"tab_visual", {"Visual", "Visual", "Visual"}},
	{"tab_particles", {"Particulas", "Particles", "Particulas"}},
	{"tab_settings", {"Ajustes", "Settings", "Config."}},
	{"tab_about", {"Info", "About", "Sobre"}},

	{"h_noclip", {"Noclip", "Noclip", "Noclip"}},
	{"noclip", {"Noclip", "Noclip", "Noclip"}},
	{"noclip_p1", {"Noclip jugador 1", "Noclip player 1", "Noclip jogador 1"}},
	{"noclip_p2", {"Noclip jugador 2", "Noclip player 2", "Noclip jogador 2"}},
	{"noclip_count", {"Contar muertes evitadas", "Count avoided deaths", "Contar mortes evitadas"}},
	{"h_speed", {"Velocidad", "Speed", "Velocidade"}},
	{"speed_on", {"Speedhack", "Speedhack", "Speedhack"}},
	{"speed", {"Velocidad del juego", "Game speed", "Velocidade do jogo"}},
	{"speed_reset", {"Restablecer velocidad (1.00x)", "Reset speed (1.00x)", "Redefinir velocidade (1.00x)"}},

	{"h_progress", {"Progreso", "Progress", "Progresso"}},
	{"safe_mode", {"Modo seguro", "Safe mode", "Modo seguro"}},
	{"safe_note", {"Con el modo seguro activo, no se guarda el porcentaje del nivel mientras haya trucos activados (noclip o velocidad distinta de 1x).",
	               "With safe mode on, level percentage is NOT saved while cheats are active (noclip or speed other than 1x).",
	               "Com o modo seguro ativo, a porcentagem do nivel NAO e salva enquanto houver trapacas ativas (noclip ou velocidade diferente de 1x)."}},
	{"h_unlock", {"Desbloqueos (solo local)", "Unlocks (local only)", "Desbloqueios (so local)"}},
	{"unlock_icons", {"Todos los iconos", "All icons", "Todos os icones"}},
	{"unlock_colors", {"Todos los colores", "All colors", "Todas as cores"}},

	{"h_hud", {"Pantalla (HUD)", "On-screen (HUD)", "Tela (HUD)"}},
	{"show_fps", {"Mostrar FPS", "Show FPS", "Mostrar FPS"}},
	{"show_clock", {"Mostrar reloj", "Show clock", "Mostrar relogio"}},
	{"hud_scale", {"Tamano del HUD", "HUD size", "Tamanho do HUD"}},
	{"h_icon", {"Icono", "Icon", "Icone"}},
	{"rainbow_icon", {"Icono arcoiris", "Rainbow icon", "Icone arco-iris"}},
	{"rainbow_speed", {"Velocidad arcoiris", "Rainbow speed", "Velocidade arco-iris"}},

	{"h_trail", {"Estela de particulas", "Particle trail", "Rastro de particulas"}},
	{"trail_on", {"Activar estela", "Enable trail", "Ativar rastro"}},
	{"trail_style", {"Estilo", "Style", "Estilo"}},
	{"trail_color", {"Color", "Color", "Cor"}},
	{"trail_size", {"Tamano", "Size", "Tamanho"}},
	{"trail_density", {"Cantidad por segundo", "Amount per second", "Quantidade por segundo"}},
	{"trail_life", {"Duracion", "Lifetime", "Duracao"}},
	{"st_sparks", {"Chispas", "Sparks", "Faiscas"}},
	{"st_fire", {"Fuego", "Fire", "Fogo"}},
	{"st_bubbles", {"Burbujas", "Bubbles", "Bolhas"}},
	{"st_diamonds", {"Rombos", "Diamonds", "Losangos"}},
	{"st_snow", {"Nieve", "Snow", "Neve"}},
	{"col_rainbow", {"Arcoiris", "Rainbow", "Arco-iris"}},
	{"col_theme", {"Tema del menu", "Menu theme", "Tema do menu"}},
	{"col_white", {"Blanco", "White", "Branco"}},

	{"h_design", {"Diseno", "Design", "Design"}},
	{"theme", {"Tema neon", "Neon theme", "Tema neon"}},
	{"th0", {"Pastel arcoiris", "Pastel rainbow", "Pastel arco-iris"}},
	{"th1", {"Rosa lavanda", "Pink lavender", "Rosa lavanda"}},
	{"th2", {"Menta cielo", "Mint sky", "Menta ceu"}},
	{"th3", {"Durazno", "Peach", "Pessego"}},
	{"th4", {"Aurora", "Aurora", "Aurora"}},
	{"border_speed", {"Velocidad del borde", "Border speed", "Velocidade da borda"}},
	{"border_width", {"Grosor del borde", "Border width", "Espessura da borda"}},
	{"border_glow", {"Brillo del borde", "Border glow", "Brilho da borda"}},
	{"menu_opacity", {"Opacidad del menu", "Menu opacity", "Opacidade do menu"}},
	{"menu_scale", {"Tamano del menu", "Menu size", "Tamanho do menu"}},
	{"h_general", {"General", "General", "Geral"}},
	{"lang", {"Idioma", "Language", "Idioma"}},
	{"open_mode", {"Abrir menu desde", "Open menu from", "Abrir menu por"}},
	{"om_pause", {"Menu de pausa", "Pause menu", "Menu de pausa"}},
	{"om_ball", {"Bolita flotante", "Floating ball", "Bolinha flutuante"}},
	{"ball_size", {"Tamano de la bolita", "Ball size", "Tamanho da bolinha"}},
	{"ball_opacity", {"Opacidad de la bolita", "Ball opacity", "Opacidade da bolinha"}},
	{"reset_all", {"Restablecer todo", "Reset everything", "Redefinir tudo"}},

	{"about_text",
	 {"Claude's Mod Menu v1.0.0\nHecho con Geode para Geometry Dash 2.2091.\n\nNoclip, speedhack, estela de particulas, HUD, desbloqueos locales y mas. En Ajustes cambias el tema neon, el idioma y si el menu se abre desde la pausa o con una bolita flotante.",
	  "Claude's Mod Menu v1.0.0\nMade with Geode for Geometry Dash 2.2091.\n\nNoclip, speedhack, particle trail, HUD, local unlocks and more. In Settings you can change the neon theme, the language and whether the menu opens from the pause menu or a floating ball.",
	  "Claude's Mod Menu v1.0.0\nFeito com Geode para Geometry Dash 2.2091.\n\nNoclip, speedhack, rastro de particulas, HUD, desbloqueios locais e mais. Em Config. voce muda o tema neon, o idioma e se o menu abre pela pausa ou por uma bolinha flutuante."}},
};

std::string tr(std::string const& key) {
	static std::unordered_map<std::string, std::array<std::string, 3>> map;
	if (map.empty()) {
		for (auto& r : TABLE) map[r.key] = {r.v[0], r.v[1], r.v[2]};
	}
	int lang = std::clamp((int)get("lang"), 0, 2);
	auto it = map.find(key);
	if (it == map.end()) return key;
	if (!it->second[lang].empty()) return it->second[lang];
	return it->second[1];
}

} // namespace cmm
