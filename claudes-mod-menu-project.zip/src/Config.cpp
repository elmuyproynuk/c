#include "Config.hpp"
#include <algorithm>
#include <unordered_map>

namespace cmm {

static std::vector<Opt> g_opts;
static std::unordered_map<std::string, double> g_vals;
static bool g_built = false;

static void H(Tab t, std::string key) {
	Opt o; o.id = key; o.tab = t; o.kind = Kind::Header; o.label = key; g_opts.push_back(o);
}
static void X(Tab t, std::string key) {
	Opt o; o.id = key; o.tab = t; o.kind = Kind::Text; o.label = key; g_opts.push_back(o);
}
static void T(Tab t, std::string id, std::string key, bool def) {
	Opt o; o.id = id; o.tab = t; o.kind = Kind::Toggle; o.label = key; o.def = def ? 1 : 0; g_opts.push_back(o);
}
static void S(Tab t, std::string id, std::string key, double def, double mn, double mx, double st, std::string suf = "") {
	Opt o; o.id = id; o.tab = t; o.kind = Kind::Slider; o.label = key;
	o.def = def; o.min = mn; o.max = mx; o.step = st; o.suffix = suf; g_opts.push_back(o);
}
static void C(Tab t, std::string id, std::string key, int def, std::vector<std::string> ch) {
	Opt o; o.id = id; o.tab = t; o.kind = Kind::Choice; o.label = key; o.def = def; o.choices = std::move(ch); g_opts.push_back(o);
}
static void B(Tab t, std::string id, std::string key, std::function<void()> fn) {
	Opt o; o.id = id; o.tab = t; o.kind = Kind::Button; o.label = key; o.act = std::move(fn); g_opts.push_back(o);
}

static void build() {
	if (g_built) return;
	g_built = true;

	// ---- Player ----
	H(Tab::Player, "h_noclip");
	T(Tab::Player, "noclip", "noclip", false);
	T(Tab::Player, "noclip_p1", "noclip_p1", true);
	T(Tab::Player, "noclip_p2", "noclip_p2", true);
	T(Tab::Player, "noclip_count", "noclip_count", false);
	H(Tab::Player, "h_speed");
	T(Tab::Player, "speed_on", "speed_on", false);
	S(Tab::Player, "speed", "speed", 1.0, 0.05, 5.0, 0.05, "x");
	B(Tab::Player, "speed_reset", "speed_reset", [] { set("speed", 1.0); });

	// ---- Level ----
	H(Tab::Level, "h_progress");
	T(Tab::Level, "safe_mode", "safe_mode", true);
	X(Tab::Level, "safe_note");
	H(Tab::Level, "h_unlock");
	T(Tab::Level, "unlock_icons", "unlock_icons", false);
	T(Tab::Level, "unlock_colors", "unlock_colors", false);

	// ---- Visual ----
	H(Tab::Visual, "h_hud");
	T(Tab::Visual, "show_fps", "show_fps", true);
	T(Tab::Visual, "show_clock", "show_clock", false);
	S(Tab::Visual, "hud_scale", "hud_scale", 1.0, 0.5, 2.0, 0.1, "x");
	H(Tab::Visual, "h_icon");
	T(Tab::Visual, "rainbow_icon", "rainbow_icon", false);
	S(Tab::Visual, "rainbow_speed", "rainbow_speed", 1.0, 0.1, 4.0, 0.1, "x");

	// ---- Particles ----
	H(Tab::Particles, "h_trail");
	T(Tab::Particles, "trail_on", "trail_on", false);
	C(Tab::Particles, "trail_style", "trail_style", 0, {"st_sparks", "st_fire", "st_bubbles", "st_diamonds", "st_snow"});
	C(Tab::Particles, "trail_color", "trail_color", 0, {"col_rainbow", "col_theme", "col_white"});
	S(Tab::Particles, "trail_size", "trail_size", 1.0, 0.3, 3.0, 0.1, "x");
	S(Tab::Particles, "trail_density", "trail_density", 50, 10, 150, 5);
	S(Tab::Particles, "trail_life", "trail_life", 0.8, 0.2, 2.0, 0.1, "s");

	// ---- Settings ----
	H(Tab::Settings, "h_design");
	C(Tab::Settings, "theme", "theme", 0, {"th0", "th1", "th2", "th3", "th4"});
	S(Tab::Settings, "border_speed", "border_speed", 1.0, 0.0, 4.0, 0.1, "x");
	S(Tab::Settings, "border_width", "border_width", 2.0, 1.0, 5.0, 0.5);
	T(Tab::Settings, "border_glow", "border_glow", true);
	S(Tab::Settings, "menu_opacity", "menu_opacity", 0.95, 0.5, 1.0, 0.05);
	S(Tab::Settings, "menu_scale", "menu_scale", 1.0, 0.6, 1.2, 0.05, "x");
	H(Tab::Settings, "h_general");
	C(Tab::Settings, "lang", "lang", 0, {"@Espanol", "@English", "@Portugues"});
	C(Tab::Settings, "open_mode", "open_mode", 1, {"om_pause", "om_ball"});
	S(Tab::Settings, "ball_size", "ball_size", 40, 26, 70, 2);
	S(Tab::Settings, "ball_opacity", "ball_opacity", 0.9, 0.3, 1.0, 0.05);
	B(Tab::Settings, "reset_all", "reset_all", [] { resetAll(); });

	// ---- About ----
	X(Tab::About, "about_text");
}

const std::vector<Opt>& options() {
	build();
	return g_opts;
}

std::string tabKey(Tab t) {
	switch (t) {
		case Tab::Player: return "tab_player";
		case Tab::Level: return "tab_level";
		case Tab::Visual: return "tab_visual";
		case Tab::Particles: return "tab_particles";
		case Tab::Settings: return "tab_settings";
		default: return "tab_about";
	}
}

double get(std::string const& id) {
	auto it = g_vals.find(id);
	return it == g_vals.end() ? 0.0 : it->second;
}

bool on(std::string const& id) { return get(id) > 0.5; }

void set(std::string const& id, double v) {
	g_vals[id] = v;
	Mod::get()->setSavedValue<double>("v_" + id, v);
}

void loadAll() {
	for (auto& o : options()) {
		if (o.kind == Kind::Header || o.kind == Kind::Text || o.kind == Kind::Button) continue;
		g_vals[o.id] = Mod::get()->getSavedValue<double>("v_" + o.id, o.def);
	}
}

void resetAll() {
	for (auto& o : options()) {
		if (o.kind == Kind::Header || o.kind == Kind::Text || o.kind == Kind::Button) continue;
		set(o.id, o.def);
	}
}

std::string choiceText(Opt const& o, int idx) {
	if (o.choices.empty()) return "";
	idx = std::clamp(idx, 0, (int)o.choices.size() - 1);
	auto const& c = o.choices[idx];
	if (!c.empty() && c[0] == '@') return c.substr(1);
	return tr(c);
}

} // namespace cmm
