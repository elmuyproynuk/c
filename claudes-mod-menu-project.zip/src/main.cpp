#include "Config.hpp"

$on_mod(Loaded) {
	cmm::loadAll();
}
