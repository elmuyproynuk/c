#include "Menu.hpp"
#include "Neon.hpp"
#include <algorithm>
#include <cmath>
#include <cstdio>

namespace cmm {
namespace {

// Panel geometry (panel-local coordinates, origin = panel centre)
constexpr float PW = 460.f, PH = 270.f;
constexpr float CX0 = -112.f, CW = 326.f, CTOP = 98.f, VIEW_H = 216.f;
constexpr float TAB_CX = -174.f, TAB_W = 92.f, TAB_H = 30.f;
const CCPoint CLOSE_P(205.f, 117.f);
const Tab TABS[6] = {Tab::Player, Tab::Level, Tab::Visual, Tab::Particles, Tab::Settings, Tab::About};

float tabY(int i) { return 78.f - 36.f * i; }

void fitWidth(CCLabelBMFont* l, float base, float maxW) {
	l->setScale(base);
	float w = l->getContentSize().width * base;
	if (w > maxW && w > 0) l->setScale(base * maxW / w);
}

// ---- scissor-clipped container (the scrolling list lives inside) ----
class ClipNode : public CCNode {
public:
	CCRect m_r;
	static ClipNode* create(CCRect r) {
		auto n = new ClipNode();
		if (n && n->init()) { n->m_r = r; n->autorelease(); return n; }
		delete n;
		return nullptr;
	}
	void visit() override {
		CCPoint a = convertToWorldSpace(CCPoint(m_r.origin.x, m_r.origin.y));
		CCPoint b = convertToWorldSpace(CCPoint(m_r.origin.x + m_r.size.width, m_r.origin.y + m_r.size.height));
		glEnable(GL_SCISSOR_TEST);
		CCEGLView::get()->setScissorInPoints(a.x, a.y, b.x - a.x, b.y - a.y);
		CCNode::visit();
		glDisable(GL_SCISSOR_TEST);
	}
};

struct Row {
	const Opt* opt = nullptr;
	CCNode* node = nullptr;
	CCDrawNode* d = nullptr;
	CCLabelBMFont* lbl = nullptr;
	CCLabelBMFont* val = nullptr;
	float y = 0, h = 0; // y = bottom edge in content-local coords
};

class NeonMenu;
NeonMenu* s_menu = nullptr;

class NeonMenu : public CCLayer {
public:
	Tab m_tab = Tab::Player;
	float m_scroll = 0.f, m_maxScroll = 0.f;
	CCNode* m_panel = nullptr;
	CCDrawNode *m_fill = nullptr, *m_deco = nullptr, *m_border = nullptr, *m_tabD = nullptr;
	CCNode* m_cont = nullptr;
	std::vector<Row> m_rows;
	std::vector<CCLabelBMFont*> m_tabLbls;
	std::vector<CCPoint> m_per;

	enum Drag { D_NONE, D_SCROLL, D_SLIDER, D_CLOSE, D_OUTSIDE };
	Drag m_drag = D_NONE;
	int m_dragRow = -1;
	CCPoint m_start, m_last;
	bool m_moved = false, m_needRebuild = false;

	static NeonMenu* create() {
		auto r = new NeonMenu();
		if (r && r->init()) { r->autorelease(); return r; }
		delete r;
		return nullptr;
	}
	~NeonMenu() override { if (s_menu == this) s_menu = nullptr; }

	bool init() override {
		if (!CCLayer::init()) return false;
		this->setTouchEnabled(true);
		this->setKeypadEnabled(true);
		build();
		this->scheduleUpdate();
		return true;
	}

	void registerWithTouchDispatcher() override {
		CCTouchDispatcher::get()->addTargetedDelegate(this, -1000, true);
	}

	void keyBackClicked() override { close(); }

	void close() {
		if (s_menu == this) s_menu = nullptr;
		this->setKeypadEnabled(false);
		this->setTouchEnabled(false);
		this->removeFromParentAndCleanup(true);
		Ball::refresh();
	}

	// ------------------------------------------------------------ build
	void build() {
		auto win = CCDirector::get()->getWinSize();
		auto dim = CCLayerColor::create(ccc4(0, 0, 0, 130));
		this->addChild(dim, 0);

		m_panel = CCNode::create();
		m_panel->setPosition(CCPoint(win.width / 2, win.height / 2));
		m_panel->setScale((float)get("menu_scale"));
		this->addChild(m_panel, 1);

		m_fill = CCDrawNode::create();
		setBlend(m_fill, false);
		m_panel->addChild(m_fill, 0);
		drawFill();

		m_deco = CCDrawNode::create();
		setBlend(m_deco, false);
		m_panel->addChild(m_deco, 1);
		drawDeco();

		m_tabD = CCDrawNode::create();
		setBlend(m_tabD, false);
		m_panel->addChild(m_tabD, 2);

		m_border = CCDrawNode::create();
		m_panel->addChild(m_border, 6);
		m_per = densify(rrect(0, 0, PW, PH, 16.f, 8), 9.f);

		// title
		auto title = CCLabelBMFont::create("Claude's Mod Menu", "bigFont.fnt");
		title->setPosition(CCPoint(51.f, 117.f));
		fitWidth(title, 0.55f, 250.f);
		m_panel->addChild(title, 3);

		// logo
		auto logo = makeNeonIcon(34.f);
		logo->setPosition(CCPoint(TAB_CX, 112.f));
		m_panel->addChild(logo, 3);

		// tabs
		m_tabLbls.clear();
		for (int i = 0; i < 6; i++) {
			auto l = CCLabelBMFont::create(tr(tabKey(TABS[i])).c_str(), "bigFont.fnt");
			l->setPosition(CCPoint(TAB_CX, tabY(i)));
			fitWidth(l, 0.42f, TAB_W - 12.f);
			m_panel->addChild(l, 4);
			m_tabLbls.push_back(l);
		}
		drawTabs();

		// scrolling content
		auto clip = ClipNode::create(CCRect(CX0, CTOP - VIEW_H, CW, VIEW_H));
		m_panel->addChild(clip, 3);
		m_cont = CCNode::create();
		clip->addChild(m_cont);
		buildRows();
	}

	void drawFill() {
		float op = (float)get("menu_opacity");
		m_fill->clear();
		auto body = rrect(0, 0, PW, PH, 16.f, 8);
		m_fill->drawPolygon(body.data(), (unsigned)body.size(), ccc4f(0.012f, 0.020f, 0.055f, op), 0.f, ccc4f(0, 0, 0, 0));
		auto side = rrect(TAB_CX, -3.f, 100.f, 240.f, 10.f, 6);
		m_fill->drawPolygon(side.data(), (unsigned)side.size(), ccc4f(0.03f, 0.05f, 0.11f, op), 0.f, ccc4f(0, 0, 0, 0));
	}

	void drawDeco() {
		m_deco->clear();
		auto ac = accent();
		// header divider
		m_deco->drawSegment(CCPoint(CX0, CTOP + 6.f), CCPoint(CX0 + CW, CTOP + 6.f), 0.7f, ccc4f(ac.r, ac.g, ac.b, 0.35f));
		// close button
		m_deco->drawDot(CLOSE_P, 12.f, ccc4f(0.06f, 0.09f, 0.18f, 1.f));
		auto c = ccc4f(ac.r, ac.g, ac.b, 1.f);
		m_deco->drawSegment(CCPoint(CLOSE_P.x - 4.5f, CLOSE_P.y - 4.5f), CCPoint(CLOSE_P.x + 4.5f, CLOSE_P.y + 4.5f), 1.1f, c);
		m_deco->drawSegment(CCPoint(CLOSE_P.x - 4.5f, CLOSE_P.y + 4.5f), CCPoint(CLOSE_P.x + 4.5f, CLOSE_P.y - 4.5f), 1.1f, c);
	}

	void drawTabs() {
		m_tabD->clear();
		auto ac = accent();
		for (int i = 0; i < 6; i++) {
			bool sel = TABS[i] == m_tab;
			if (sel) {
				auto r = rrect(TAB_CX, tabY(i), TAB_W, TAB_H, 8.f, 5);
				m_tabD->drawPolygon(r.data(), (unsigned)r.size(), ccc4f(ac.r, ac.g, ac.b, 0.16f), 1.f, ccc4f(ac.r, ac.g, ac.b, 0.85f));
			}
			if (i < (int)m_tabLbls.size()) m_tabLbls[i]->setOpacity(sel ? 255 : 150);
		}
	}

	void drawBorder() {
		m_border->clear();
		float speed = (float)get("border_speed");
		float width = (float)get("border_width");
		bool glow = on("border_glow");
		size_t n = m_per.size();
		if (n < 3) return;
		float t = g_time * speed * 0.18f;
		if (glow) {
			setBlend(m_border, true);
			for (size_t i = 0; i + 2 < n; i += 2) {
				auto c = themeColor((float)i / n * 2.f - t);
				m_border->drawSegment(m_per[i], m_per[i + 2], width * 2.2f, ccc4f(c.r, c.g, c.b, 0.16f));
			}
		}
		for (size_t i = 0; i + 1 < n; i++) {
			auto c = themeColor((float)i / n * 2.f - t);
			m_border->drawSegment(m_per[i], m_per[i + 1], width * 0.5f, c);
		}
	}

	// ------------------------------------------------------------ rows
	float rowHeight(Opt const& o, CCLabelBMFont* textLbl) {
		switch (o.kind) {
			case Kind::Header: return 24.f;
			case Kind::Slider: return 40.f;
			case Kind::Text: return textLbl->getContentSize().height * textLbl->getScale() + 12.f;
			default: return 30.f;
		}
	}

	void buildRows() {
		m_cont->removeAllChildren();
		m_rows.clear();
		float used = 0.f;
		for (auto const& o : options()) {
			if (o.tab != m_tab) continue;
			Row r;
			r.opt = &o;
			r.node = CCNode::create();
			r.d = CCDrawNode::create();
			setBlend(r.d, false);
			r.node->addChild(r.d, 0);

			if (o.kind == Kind::Text) {
				r.lbl = CCLabelBMFont::create(tr(o.label).c_str(), "chatFont.fnt", (CW - 20.f) / 0.7f, kCCTextAlignmentLeft);
				r.lbl->setScale(0.7f);
				r.lbl->setColor(ccc3(190, 200, 225));
				r.lbl->setAnchorPoint(CCPoint(0.f, 1.f));
			} else {
				r.lbl = CCLabelBMFont::create(tr(o.label).c_str(), "bigFont.fnt");
				r.lbl->setAnchorPoint(CCPoint(0.f, 0.5f));
			}
			r.node->addChild(r.lbl, 2);
			if (o.kind == Kind::Slider || o.kind == Kind::Choice) {
				r.val = CCLabelBMFont::create("", "bigFont.fnt");
				r.node->addChild(r.val, 2);
			}
			r.h = rowHeight(o, r.lbl);
			r.y = -(used + r.h);
			r.node->setPosition(CCPoint(CX0, r.y));
			m_cont->addChild(r.node);
			used += r.h + 4.f;
			m_rows.push_back(r);
		}
		for (int i = 0; i < (int)m_rows.size(); i++) drawRow(i);
		m_maxScroll = std::max(0.f, used - VIEW_H);
		m_scroll = std::clamp(m_scroll, 0.f, m_maxScroll);
		m_cont->setPosition(CCPoint(0.f, CTOP + m_scroll));
	}

	void drawRow(int i) {
		auto& r = m_rows[i];
		auto const& o = *r.opt;
		r.d->clear();
		const float W = CW, h = r.h;
		auto ac = accent();
		auto acA = [&](float a) { return ccc4f(ac.r, ac.g, ac.b, a); };

		if (o.kind != Kind::Header && o.kind != Kind::Text) {
			auto bg = rrect(W / 2, h / 2, W - 2.f, h - 2.f, 8.f, 5);
			r.d->drawPolygon(bg.data(), (unsigned)bg.size(), ccc4f(0.05f, 0.08f, 0.16f, 0.9f), 0.8f, acA(0.25f));
		}

		switch (o.kind) {
			case Kind::Header: {
				r.lbl->setPosition(CCPoint(4.f, h / 2 + 1.f));
				r.lbl->setColor(to3B(ac));
				fitWidth(r.lbl, 0.42f, W - 20.f);
				r.d->drawSegment(CCPoint(4.f, 2.f), CCPoint(W - 4.f, 2.f), 0.7f, acA(0.45f));
				break;
			}
			case Kind::Text: {
				r.lbl->setPosition(CCPoint(10.f, h - 6.f));
				break;
			}
			case Kind::Toggle: {
				bool v = on(o.id);
				r.lbl->setPosition(CCPoint(10.f, h / 2));
				fitWidth(r.lbl, 0.4f, W - 76.f);
				float cx = W - 30.f, cy = h / 2;
				auto pill = rrect(cx, cy, 36.f, 16.f, 8.f, 5);
				r.d->drawPolygon(pill.data(), (unsigned)pill.size(), v ? acA(0.9f) : ccc4f(0.16f, 0.18f, 0.27f, 1.f), 0.f, ccc4f(0, 0, 0, 0));
				r.d->drawDot(CCPoint(cx + (v ? 10.f : -10.f), cy), 6.5f, v ? ccc4f(1, 1, 1, 1) : ccc4f(0.55f, 0.6f, 0.72f, 1.f));
				break;
			}
			case Kind::Slider: {
				double t = (get(o.id) - o.min) / (o.max - o.min);
				t = std::clamp(t, 0.0, 1.0);
				r.lbl->setPosition(CCPoint(10.f, h - 11.f));
				fitWidth(r.lbl, 0.38f, W - 90.f);
				char buf[48];
				if (o.step >= 1.0) std::snprintf(buf, sizeof buf, "%.0f%s", get(o.id), o.suffix.c_str());
				else std::snprintf(buf, sizeof buf, "%.2f%s", get(o.id), o.suffix.c_str());
				r.val->setString(buf);
				r.val->setAnchorPoint(CCPoint(1.f, 0.5f));
				r.val->setPosition(CCPoint(W - 10.f, h - 11.f));
				r.val->setScale(0.36f);
				float x0 = 12.f, x1 = W - 12.f, y = 11.f, kx = x0 + (x1 - x0) * (float)t;
				r.d->drawSegment(CCPoint(x0, y), CCPoint(x1, y), 2.5f, ccc4f(0.15f, 0.18f, 0.29f, 1.f));
				r.d->drawSegment(CCPoint(x0, y), CCPoint(kx, y), 2.5f, acA(0.95f));
				r.d->drawDot(CCPoint(kx, y), 7.5f, acA(0.35f));
				r.d->drawDot(CCPoint(kx, y), 5.2f, ccc4f(1, 1, 1, 1));
				break;
			}
			case Kind::Choice: {
				int idx = (int)get(o.id);
				r.lbl->setPosition(CCPoint(10.f, h / 2));
				fitWidth(r.lbl, 0.4f, W - 160.f);
				float cx = W - 70.f, cy = h / 2;
				auto pill = rrect(cx, cy, 128.f, 20.f, 10.f, 5);
				r.d->drawPolygon(pill.data(), (unsigned)pill.size(), acA(0.12f), 1.f, acA(0.7f));
				CCPoint L[3] = {CCPoint(cx - 56.f, cy), CCPoint(cx - 50.f, cy + 5.f), CCPoint(cx - 50.f, cy - 5.f)};
				CCPoint R[3] = {CCPoint(cx + 56.f, cy), CCPoint(cx + 50.f, cy + 5.f), CCPoint(cx + 50.f, cy - 5.f)};
				r.d->drawPolygon(L, 3, acA(1.f), 0.f, ccc4f(0, 0, 0, 0));
				r.d->drawPolygon(R, 3, acA(1.f), 0.f, ccc4f(0, 0, 0, 0));
				r.val->setString(choiceText(o, idx).c_str());
				r.val->setAnchorPoint(CCPoint(0.5f, 0.5f));
				r.val->setPosition(CCPoint(cx, cy));
				fitWidth(r.val, 0.36f, 84.f);
				break;
			}
			case Kind::Button: {
				r.lbl->setAnchorPoint(CCPoint(0.5f, 0.5f));
				r.lbl->setPosition(CCPoint(W / 2, h / 2));
				fitWidth(r.lbl, 0.4f, W - 24.f);
				auto pill = rrect(W / 2, h / 2, W - 10.f, h - 8.f, 9.f, 5);
				r.d->drawPolygon(pill.data(), (unsigned)pill.size(), acA(0.14f), 1.f, acA(0.8f));
				break;
			}
		}
	}

	// ------------------------------------------------------------ input
	void setSliderFromX(int i, float localX) {
		auto& r = m_rows[i];
		auto const& o = *r.opt;
		float t = std::clamp((localX - 12.f) / (CW - 24.f), 0.f, 1.f);
		double v = o.min + t * (o.max - o.min);
		v = std::round(v / o.step) * o.step;
		v = std::clamp(v, o.min, o.max);
		if (std::abs(v - get(o.id)) < 1e-9) return;
		set(o.id, v);
		drawRow(i);
		onChanged(o.id);
	}

	void tapRow(int i, float localX) {
		auto& r = m_rows[i];
		auto const& o = *r.opt;
		switch (o.kind) {
			case Kind::Toggle:
				set(o.id, on(o.id) ? 0.0 : 1.0);
				drawRow(i);
				onChanged(o.id);
				break;
			case Kind::Choice: {
				int n = (int)o.choices.size();
				int idx = (int)get(o.id);
				bool prev = localX > CW - 134.f && localX < CW - 70.f;
				idx = (idx + (prev ? n - 1 : 1)) % n;
				set(o.id, idx);
				drawRow(i);
				onChanged(o.id);
				break;
			}
			case Kind::Button:
				if (o.act) o.act();
				m_needRebuild = true;
				Ball::refresh();
				break;
			default: break;
		}
	}

	void onChanged(std::string const& id) {
		if (id == "menu_scale") m_panel->setScale((float)get("menu_scale"));
		else if (id == "menu_opacity") drawFill();
		else if (id == "lang" || id == "theme") m_needRebuild = true;
		else if (id == "open_mode" || id == "ball_size" || id == "ball_opacity") Ball::refresh();
	}

	void rebuild() {
		m_needRebuild = false;
		this->removeAllChildrenWithCleanup(true);
		m_rows.clear();
		m_tabLbls.clear();
		build();
	}

	bool ccTouchBegan(CCTouch* t, CCEvent*) override {
		CCPoint p = m_panel->convertToNodeSpace(t->getLocation());
		m_start = m_last = p;
		m_moved = false;
		m_drag = D_NONE;
		m_dragRow = -1;

		if (std::fabs(p.x) > PW / 2 || std::fabs(p.y) > PH / 2) { m_drag = D_OUTSIDE; return true; }
		if (ccpDistance(p, CLOSE_P) < 18.f) { m_drag = D_CLOSE; return true; }

		for (int i = 0; i < 6; i++) {
			if (std::fabs(p.x - TAB_CX) < TAB_W / 2 && std::fabs(p.y - tabY(i)) < TAB_H / 2 + 3.f) {
				if (TABS[i] != m_tab) {
					m_tab = TABS[i];
					m_scroll = 0.f;
					drawTabs();
					buildRows();
				}
				return true;
			}
		}

		if (p.x >= CX0 && p.x <= CX0 + CW && p.y >= CTOP - VIEW_H && p.y <= CTOP) {
			m_drag = D_SCROLL;
			CCPoint lp(p.x - CX0, p.y - m_cont->getPositionY());
			for (int i = 0; i < (int)m_rows.size(); i++) {
				auto& r = m_rows[i];
				if (lp.y >= r.y && lp.y <= r.y + r.h) {
					m_dragRow = i;
					if (r.opt->kind == Kind::Slider && lp.y - r.y < 24.f) {
						m_drag = D_SLIDER;
						setSliderFromX(i, lp.x);
					}
					break;
				}
			}
		}
		return true; // swallow everything while the menu is open
	}

	void ccTouchMoved(CCTouch* t, CCEvent*) override {
		CCPoint p = m_panel->convertToNodeSpace(t->getLocation());
		if (m_drag == D_SLIDER && m_dragRow >= 0) {
			setSliderFromX(m_dragRow, p.x - CX0);
		} else if (m_drag == D_SCROLL) {
			if (!m_moved && std::fabs(p.y - m_start.y) > 6.f) m_moved = true;
			if (m_moved) {
				m_scroll = std::clamp(m_scroll + (p.y - m_last.y), 0.f, m_maxScroll);
				m_cont->setPositionY(CTOP + m_scroll);
			}
		}
		m_last = p;
	}

	void ccTouchEnded(CCTouch* t, CCEvent*) override {
		CCPoint p = m_panel->convertToNodeSpace(t->getLocation());
		if (m_drag == D_CLOSE && ccpDistance(p, CLOSE_P) < 22.f) { close(); return; }
		if (m_drag == D_OUTSIDE && (std::fabs(p.x) > PW / 2 || std::fabs(p.y) > PH / 2)) { close(); return; }
		if (m_drag == D_SCROLL && !m_moved && m_dragRow >= 0) tapRow(m_dragRow, m_start.x - CX0);
		m_drag = D_NONE;
		if (m_needRebuild) rebuild();
	}

	void ccTouchCancelled(CCTouch*, CCEvent*) override { m_drag = D_NONE; }

	void update(float dt) override {
		g_time += dt;
		drawBorder();
	}
};

// ================================================================= floating ball
class FloatBall;
FloatBall* s_ball = nullptr;

class FloatBall : public CCLayer {
public:
	CCDrawNode* m_d = nullptr;
	CCLabelBMFont* m_lbl = nullptr;
	CCPoint m_pos, m_target, m_off, m_start;
	bool m_drag = false, m_moved = false, m_snap = false;
	float m_idle = 0.f;

	static FloatBall* create() {
		auto r = new FloatBall();
		if (r && r->init()) { r->autorelease(); return r; }
		delete r;
		return nullptr;
	}

	float radius() { return (float)get("ball_size") / 2.f; }

	bool init() override {
		if (!CCLayer::init()) return false;
		m_d = CCDrawNode::create();
		setBlend(m_d, false);
		this->addChild(m_d, 0);
		m_lbl = CCLabelBMFont::create("C", "bigFont.fnt");
		this->addChild(m_lbl, 1);

		auto win = CCDirector::get()->getWinSize();
		float fx = Mod::get()->getSavedValue<float>("ball_fx", 0.97f);
		float fy = Mod::get()->getSavedValue<float>("ball_fy", 0.55f);
		m_pos = CCPoint(fx * win.width, fy * win.height);
		clampPos();
		this->setTouchEnabled(true);
		this->scheduleUpdate();
		return true;
	}

	void registerWithTouchDispatcher() override {
		CCTouchDispatcher::get()->addTargetedDelegate(this, -900, true);
	}

	bool active() { return get("open_mode") > 0.5 && !Menu::isOpen(); }

	void clampPos() {
		auto win = CCDirector::get()->getWinSize();
		float r = radius();
		m_pos.x = std::clamp(m_pos.x, r + 2.f, win.width - r - 2.f);
		m_pos.y = std::clamp(m_pos.y, r + 2.f, win.height - r - 2.f);
	}

	void save() {
		auto win = CCDirector::get()->getWinSize();
		Mod::get()->setSavedValue<float>("ball_fx", m_pos.x / win.width);
		Mod::get()->setSavedValue<float>("ball_fy", m_pos.y / win.height);
	}

	bool ccTouchBegan(CCTouch* t, CCEvent*) override {
		if (!active()) return false;
		CCPoint p = t->getLocation();
		if (ccpDistance(p, m_pos) > radius() + 6.f) return false;
		m_drag = true;
		m_moved = false;
		m_snap = false;
		m_start = p;
		m_off = m_pos - p;
		m_idle = 0.f;
		return true;
	}

	void ccTouchMoved(CCTouch* t, CCEvent*) override {
		CCPoint p = t->getLocation();
		if (!m_moved && ccpDistance(p, m_start) > 10.f) m_moved = true;
		if (m_moved) { m_pos = p + m_off; clampPos(); }
	}

	void ccTouchEnded(CCTouch*, CCEvent*) override {
		m_drag = false;
		m_idle = 0.f;
		if (!m_moved) { Menu::open(); return; }
		auto win = CCDirector::get()->getWinSize();
		float r = radius();
		m_target = CCPoint(m_pos.x < win.width / 2 ? r + 3.f : win.width - r - 3.f, m_pos.y);
		m_snap = true;
	}

	void ccTouchCancelled(CCTouch*, CCEvent*) override { m_drag = false; }

	void update(float dt) override {
		bool act = active();
		m_d->setVisible(act);
		m_lbl->setVisible(act);
		if (!act) return;
		g_time += dt;
		m_idle += dt;

		if (m_snap) {
			m_pos = m_pos + (m_target - m_pos) * std::min(1.f, dt * 14.f);
			if (ccpDistance(m_pos, m_target) < 0.5f) { m_pos = m_target; m_snap = false; save(); }
		}

		float r = radius();
		float a = (float)get("ball_opacity") * ((m_idle > 3.f && !m_drag) ? 0.5f : 1.f);
		m_d->clear();
		m_d->drawDot(m_pos, r + 3.f, ccc4f(0.4f, 0.5f, 1.f, 0.10f * a));
		m_d->drawDot(m_pos, r, ccc4f(0.012f, 0.020f, 0.055f, 0.95f * a));
		const int N = 40;
		float spd = (float)get("border_speed");
		for (int i = 0; i < N; i++) {
			float a0 = (float)i / N * 6.2831853f, a1 = (float)(i + 1) / N * 6.2831853f;
			CCPoint p0(m_pos.x + std::cos(a0) * (r - 1.5f), m_pos.y + std::sin(a0) * (r - 1.5f));
			CCPoint p1(m_pos.x + std::cos(a1) * (r - 1.5f), m_pos.y + std::sin(a1) * (r - 1.5f));
			auto c = themeColor((float)i / N - g_time * 0.2f * spd, a);
			m_d->drawSegment(p0, p1, 1.4f, c);
		}
		m_lbl->setPosition(m_pos);
		m_lbl->setScale(r / 20.f * 0.75f);
		m_lbl->setColor(to3B(accent()));
		m_lbl->setOpacity((GLubyte)(a * 255));
	}
};

} // namespace

// ------------------------------------------------------------------ public API
void Menu::open() {
	if (s_menu) return;
	auto scene = CCDirector::get()->getRunningScene();
	if (!scene) return;
	auto m = NeonMenu::create();
	if (!m) return;
	s_menu = m;
	scene->addChild(m, 100001);
	Ball::refresh();
}

bool Menu::isOpen() { return s_menu != nullptr; }

void Ball::ensure() {
	if (s_ball) return;
	auto b = FloatBall::create();
	if (!b) return;
	b->setZOrder(100000);
	SceneManager::get()->keepAcrossScenes(b);
	s_ball = b;
}

void Ball::refresh() {
	if (!s_ball) return;
	s_ball->clampPos();
	s_ball->m_idle = 0.f;
}

CCNode* makeNeonIcon(float size) {
	auto root = CCNode::create();
	root->setContentSize(CCSize(size, size));
	root->setAnchorPoint(CCPoint(0.5f, 0.5f));
	auto d = CCDrawNode::create();
	setBlend(d, false);
	root->addChild(d);
	float r = size / 2.f;
	CCPoint c(r, r);
	d->drawDot(c, r, ccc4f(0.012f, 0.020f, 0.055f, 0.97f));
	const int N = 32;
	for (int i = 0; i < N; i++) {
		float a0 = (float)i / N * 6.2831853f, a1 = (float)(i + 1) / N * 6.2831853f;
		CCPoint p0(c.x + std::cos(a0) * (r - 1.5f), c.y + std::sin(a0) * (r - 1.5f));
		CCPoint p1(c.x + std::cos(a1) * (r - 1.5f), c.y + std::sin(a1) * (r - 1.5f));
		d->drawSegment(p0, p1, 1.3f, themeColor((float)i / N));
	}
	auto l = CCLabelBMFont::create("C", "bigFont.fnt");
	l->setScale(size / 20.f * 0.75f);
	l->setColor(to3B(accent()));
	l->setPosition(c);
	root->addChild(l, 1);
	return root;
}

} // namespace cmm
