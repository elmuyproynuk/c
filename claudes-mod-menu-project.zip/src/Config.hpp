#pragma once
#include <Geode/Geode.hpp>
#include <functional>
#include <string>
#include <vector>

using namespace geode::prelude;

namespace cmm {

enum class Tab { Player, Level, Visual, Particles, Settings, About };
enum class Kind { Toggle, Slider, Choice, Button, Header, Text };

// One entry of the menu. Add a line in Config.cpp -> it shows up in the menu automatically.
struct Opt {
	std::string id;      // saved-value key (headers/text: just a unique name)
	Tab tab;
	Kind kind;
	std::string label;   // translation key
	double def = 0, min = 0, max = 1, step = 0.1;
	std::string suffix;
	std::vector<std::string> choices; // translation keys; a leading '@' means "show literally"
	std::function<void()> act;        // for Kind::Button
};

const std::vector<Opt>& options();
std::string tabKey(Tab t);

double get(std::string const& id);
bool on(std::string const& id);
void set(std::string const& id, double v);
void loadAll();
void resetAll();

std::string tr(std::string const& key);
std::string choiceText(Opt const& o, int idx);

} // namespace cmm
