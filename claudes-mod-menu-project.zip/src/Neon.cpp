#include "Neon.hpp"
#include <algorithm>
#include <cmath>

namespace cmm {

float g_time = 0.f;

ccColor4F hsv(float h, float s, float v, float a) {
	h = h - std::floor(h);
	float r, g, b;
	int i = (int)(h * 6.f);
	float f = h * 6.f - i;
	float p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
	switch (i % 6) {
		case 0: r = v; g = t; b = p; break;
		case 1: r = q; g = v; b = p; break;
		case 2: r = p; g = v; b = t; break;
		case 3: r = p; g = q; b = v; break;
		case 4: r = t; g = p; b = v; break;
		default: r = v; g = p; b = q; break;
	}
	return ccc4f(r, g, b, a);
}

ccColor4F themeColor(float phase, float a) {
	static const float H0[5] = {0.f, .72f, .42f, .02f, .35f};
	static const float HR[5] = {1.f, .23f, .16f, .09f, .43f};
	int th = std::clamp((int)get("theme"), 0, 4);
	float p = phase - std::floor(phase);
	float h;
	if (th == 0) h = p;
	else {
		float tri = p < .5f ? p * 2.f : 2.f - 2.f * p;
		h = H0[th] + HR[th] * tri;
	}
	return hsv(h, th == 3 ? .42f : .38f, 1.f, a); // low saturation, full value = pastel
}

ccColor4F accent(float a) { return themeColor(0.3f, a); }

std::vector<CCPoint> rrect(float cx, float cy, float w, float h, float r, int seg) {
	std::vector<CCPoint> out;
	r = std::min(r, std::min(w, h) / 2.f);
	float hw = w / 2.f, hh = h / 2.f;
	CCPoint c[4] = {
		CCPoint(cx + hw - r, cy + hh - r), CCPoint(cx - hw + r, cy + hh - r),
		CCPoint(cx - hw + r, cy - hh + r), CCPoint(cx + hw - r, cy - hh + r)};
	for (int k = 0; k < 4; k++) {
		for (int i = 0; i <= seg; i++) {
			float ang = (k * 90.f + 90.f * i / seg) * 3.14159265f / 180.f;
			out.push_back(CCPoint(c[k].x + std::cos(ang) * r, c[k].y + std::sin(ang) * r));
		}
	}
	return out;
}

std::vector<CCPoint> densify(std::vector<CCPoint> const& poly, float step) {
	std::vector<CCPoint> out;
	size_t n = poly.size();
	for (size_t i = 0; i < n; i++) {
		CCPoint a = poly[i], b = poly[(i + 1) % n];
		float d = std::sqrt((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y));
		int parts = std::max(1, (int)std::ceil(d / step));
		for (int k = 0; k < parts; k++) {
			float t = (float)k / parts;
			out.push_back(CCPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t));
		}
	}
	if (!out.empty()) out.push_back(out[0]);
	return out;
}

void setBlend(CCDrawNode* n, bool additive) {
	ccBlendFunc b;
	b.src = GL_SRC_ALPHA;
	b.dst = additive ? GL_ONE : GL_ONE_MINUS_SRC_ALPHA;
	n->setBlendFunc(b);
}

} // namespace cmm
