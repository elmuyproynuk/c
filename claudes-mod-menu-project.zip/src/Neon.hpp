#pragma once
#include "Config.hpp"

namespace cmm {

extern float g_time; // animation clock shared by menu + ball

ccColor4F hsv(float h, float s, float v, float a = 1.f);
// Pastel neon colour for the current theme. phase: any float, wraps every 1.0
ccColor4F themeColor(float phase, float a = 1.f);
ccColor4F accent(float a = 1.f);
inline ccColor3B to3B(ccColor4F c) {
	return ccc3((GLubyte)(c.r * 255), (GLubyte)(c.g * 255), (GLubyte)(c.b * 255));
}

// Convex rounded rectangle (counter-clockwise), centred at (cx,cy)
std::vector<CCPoint> rrect(float cx, float cy, float w, float h, float r, int seg = 6);
// Resample a closed polygon so points are ~step apart (last point == first)
std::vector<CCPoint> densify(std::vector<CCPoint> const& poly, float step);

void setBlend(CCDrawNode* n, bool additive);

} // namespace cmm
