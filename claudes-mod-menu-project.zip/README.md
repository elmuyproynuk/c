# Claude's Mod Menu (Geode, GD 2.2091)

Menu neon con bordes pastel animados. Secciones: Jugador (noclip, speedhack), Nivel (modo seguro, desbloqueos locales),
Visual (FPS, reloj, icono arcoiris), Particulas (estela con 5 estilos), Ajustes (tema, idioma, bolita o menu de pausa) e Info.

## Compilar desde el celular (GitHub Actions)
1. Crea una cuenta en github.com y un repositorio nuevo (publico).
2. En el repo: Add file > Create new file. Nombre: `.github/workflows/build.yml` (escribe las `/` y se crean las carpetas). Pega el contenido de ese archivo del zip. Commit.
3. Add file > Upload files: sube el zip del proyecto tal cual (no lo descomprimas). El workflow lo desempaqueta solo.
4. Pestana Actions > espera el build (~5-10 min). Si sale en verde, abre la ejecucion > Artifacts > "Build Output".
5. Descomprime y abre el `.geode` de Android64 con el Geode Launcher (o copialo a la carpeta `geode/mods`).

## Si falla
- Error de version de `geode` en mod.json: pon en `mod.json` la version exacta que diga el error (el nightly cambia).
- Error de bindings de 2.2091: el nightly aun puede no tenerlos; reintenta mas tarde.
- Errores de firma en `savePercentage`, `isColorUnlocked`, etc.: pegame el log y lo ajusto.

## Agregar opciones
Todas viven en `src/Config.cpp` (una linea por opcion) y los textos en `src/Lang.cpp`.
